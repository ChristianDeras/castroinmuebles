

<?php $__env->startSection('contenedor'); ?>

<div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="text-center">Extranjeros</h3>
            </div>
            <div class="col-6">
                <p>Personas solicitantes de Estados Unidos:</p>
            </div>
            <div class="col-12">
            <table id="example" class="hover" style="width:100%">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Dui</th>
                <th>Telefono</th>
                <th>Correo</th>
                <th>Descripcion</th>
                <th>Fecha:</th>
                <th>Operaciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $extranjeros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extranjero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($extranjero->nombrecompleto); ?></td>
                <td><?php echo e($extranjero->Dui); ?></td>
                <td><?php echo e($extranjero->telefono); ?></td>
                <td><?php echo e($extranjero->correo); ?></td>
                <td><?php echo e($extranjero->descripcion); ?></td>
                <td><?php echo e($extranjero->created_at); ?></td>
                <td><button class="btn btn-warning">Quitar</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </tbody>
        <tfoot>
            <tr>
                <th>Nombre</th>
                <th>Dui</th>
                <th>Telefono</th>
                <th>Correo</th>
                <th>Descripcion</th>
                <th>Fecha:</th>
                <th>Operaciones</th>
            </tr>
        </tfoot>
    </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutsAdmin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\castroinmuebles\resources\views/extranjerosAdmon/index.blade.php ENDPATH**/ ?>