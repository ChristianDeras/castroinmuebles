

<?php $__env->startSection('contenedor'); ?>

    a

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutsAdmin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\castroinmuebles\resources\views/CorretajesAdmon/index.blade.php ENDPATH**/ ?>