

<?php $__env->startSection('contenedor'); ?>

<div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="text-center">Remodelaciones</h3>
            </div>
            <div class="col-6">
                <p>Personas solicitantes de remodelaciones:</p>
            </div>
            <div class="col-12">
            <table id="example" class="hover" style="width:100%">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Telefono</th>
                <th>Tipo</th>
                <th>Presupuesto</th>
                <th>Departamento</th>
                <th>Municipio</th>
                <th>Estado</th>
                <th>Fecha:</th>
                <th>Operaciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $remo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($remos->nombrecompleto); ?></td>
                <td><?php echo e($remos->correo); ?></td>
                <td><?php echo e($remos->telefono); ?></td>
                <td><?php echo e($remos->tipo); ?></td>
                <td>$<?php echo e($remos->presupuesto); ?></td>
                <td><?php echo e($remos->departamento); ?></td>
                <td><?php echo e($remos->municipio); ?></td>
                <td><?php echo e(($remos->estado = 1)? 'Activo': 'Inactivo'); ?></td>
                <td><?php echo e($remos->created_at); ?></td>
                <td><button class="btn btn-warning">Quitar</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </tbody>
        <tfoot>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Telefono</th>
                <th>Tipo</th>
                <th>Presupuesto</th>
                <th>Departamento</th>
                <th>Municipio</th>
                <th>Estado</th>
                <th>Fecha:</th>
                <th>Operaciones</th>
            </tr>
        </tfoot>
    </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutsAdmin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\castroinmuebles\resources\views/remoAdmon/index.blade.php ENDPATH**/ ?>