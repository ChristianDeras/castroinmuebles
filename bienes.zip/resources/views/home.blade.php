@extends('layouts.header')

@section('contenidoPrincipal')
<div
      id="info"
      class="p-5 text-center bg-image d-flex justify-content-center"
      style="
        background-image: url('/Img/hero.jpg');
        background-image: no-repeat;
        background-image: fixed;
        background-image: center;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
        height: 550px;
      "
    >
      <div class="mask w-100" style="background-color: rgba(31, 41, 40, 0.6)">
        <div class="d-flex justify-content-center align-items-center h-100">
          <div class="text-white d-flex justify-content-center flex-column align-items-center">
            <div class="img-circle d-flex justify-content-center align-items-center"><img src="/Img/Logo CC-02.png" alt="" class="img-fluid" width="400"></div>
            <h4 class="mb-3 font-rowdies">
              Buscamos brindarle una atencion asesorada en cada momento del
              tramite
            </h4>
            <a class="btn btn-outline-light btn-lg" href="#!" role="button"
              id="about">Perfecto, muestrame</a
            >
          </div>
        </div>
      </div>
    </div>
    <div class="d-flex justify-content-center align-items-center " >
      <div class="separator d-flex justify-content-around align-items-center">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
      </div>
    </div>
    <div class="container-fluid section-color">
      <div class="row">
        <div class="col-sm-12">
          <h1 class="text-center font-rowdies">¿Quienes somos?</h1>
        </div>
      </div>
     
      <div class="row aniview" data-av-animation="slideInRight">
        <div class="col-sm-8 d-flex justify-content-center align-items-center mt-5">
          <div class="info w-75 justify">
            <span class="font-normal">Somos una agencia inmobiliaria encargada de la compra y venta de viviendas con más de 15 años de experiencia
              en el rubro, nuestro objetivo es asesorarte de la mejor manera y ofrecerte una atención de calidad, acontinuación
              en la web puedes encontrar información de contacto y de tramites para obtener mayor información</span>
              <br>
              <br>
            <span class=""><b>Carlos Castro.</b></span>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="img d-flex justify-content-center position-relative align-items-center">
            <div class="shape">
              <img src="/Img/triangulo1.png" alt="" class="img-fluid overflow">
            </div>
            <img src="/Img/hombre2.png" alt="" class="img-fluid rounded-circle" width="200">
          </div>
        </div>
      </div>
    </div>
    
    <div class="d-flex justify-content-center align-items-center " id="servicios">
      <div class="separator d-flex justify-content-around align-items-center">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
      </div>
    </div>
     <!-- Inicio de servicios -->
     <div class="row mt-5">
      <div class="col-sm-12">
        <h1 class="text-center font-rowdies" >Servicios</h1>
      </div>
    </div>
    <div class="container">
      
      <div class="row">
        
        <div class="col-12">
          <div class="d-flex justify-content-center mt-5 scale aniview " data-av-animation="slideInUp">
            <div class="card d-flex flex-row align-items-center overflow-hidden w-100">
              <div class="figure">
                <div class="circle-lg"></div>
              </div>
              <div class="card-body">
                <h5 class="card-title">Servicio de corretaje</h5>
                <p class="card-text">El mejor servicio para poder vender tu propiedad.</p>
                <button type="button" class="btn btn-success btn-color "><a href="/corretaje" class="text-decoration-none font-primary">Acceder al servicio</a></button>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12">
          <div class="d-flex justify-content-center mt-5 scale aniview " data-av-animation="slideInUp">
            <div class="card d-flex flex-row align-items-center overflow-hidden w-100 ">
              <div class="figure">
                <div class="circle-lg"></div>
              </div>
              <div class="card-body">
                <h5 class="card-title">Remodelaciones y construcciones</h5>
                <p class="card-text">Ofrecemos servicios de remodelación y construcción para su vivienda solo deverás rellenar
                  un pequeño formulario acontinuación.
                </p>
                <button type="button" class="btn btn-success btn-color"><a href="/remodelaciones" class="text-decoration-none font-primary">Acceder al servicio</a></button>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12">
          <div class="d-flex justify-content-center mt-5 scale aniview" data-av-animation="slideInUp" >
            <div class="card d-flex flex-row align-items-center overflow-hidden w-100">
              <div class="figure">
                <div class="circle-lg"></div>
              </div>
              <div class="card-body">
                <h5 class="card-title">Servicios extra</h5>
                <p class="card-text">
                  Realizamos servicios de:
                  <ul class="d-flex justify-content-around">
                    <li>Valuos</li>
                    <li>Mediciones</li>
                    <li>Remediciones</li>
                    <li>Lotificaciones</li>
                  </ul>
                </p>
                <button type="button" class="btn btn-success btn-color" id="viviendas"><a href="/corretaje" class="text-decoration-none font-primary">Acceder al servicio</a></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>






   

    <!-- Inicio de servicios -->
    <div class="row mt-5">
      <div class="col-sm-12">
        <h1 class="text-center font-rowdies" >Viviendas</h1>
      </div>
    </div>
    

    <div class="viviendas position-relative d-flex flex-wrap">
      <div class="shape2">
        <img src="/Img/Barras izq 2.png" alt="" class="img-fluid">
      </div>
      <div class="row d-flex justify-content-center ">
        <div class="col-md-4 col-sm-12">
          <div class="profile-card-4 text-center aniview" data-av-animation="pulse"><img src="/Img/hero.webp"
              class="img img-fluid">
            <div class="profile-content mt-5">
              <div class="profile-name">Nombre inmueble
              </div>
              <div class="profile-description">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                tempor.</div>
              <div class="row d-flex flex-wrap">
                <div class="col-6">
                  <div class="profile-overview">
                    <p><b>Precio</b></p>
                    <h4>13000</h4>
                  </div>
                </div>
                <div class="col-6">
                  <div class="profile-overview">
                    <button class="btn btn-success"><a href="/viviendas" class="text-decoration-none">Más información</a></button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-12">
          <div class="profile-card-4 text-center aniview" data-av-animation="pulse"><img src="/Img/hero.webp"
              class="img img-fluid">
            <div class="profile-content mt-5">
              <div class="profile-name">Nombre inmueble
              </div>
              <div class="profile-description">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                tempor.</div>
              <div class="row d-flex flex-wrap">
                <div class="col-6">
                  <div class="profile-overview">
                    <p><b>Precio</b></p>
                    <h4>13000</h4>
                  </div>
                </div>
                <div class="col-6">
                  <div class="profile-overview">
                    <button class="btn btn-success">Más información</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-12">
          <div class="profile-card-4 text-center aniview" data-av-animation="pulse"><img src="/Img/hero.webp"
              class="img img-fluid">
            <div class="profile-content mt-5">
              <div class="profile-name">Nombre inmueble
              </div>
              <div class="profile-description">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                tempor.</div>
              <div class="row d-flex flex-wrap">
                <div class="col-6">
                  <div class="profile-overview">
                    <p><b>Precio</b></p>
                    <h4>13000</h4>
                  </div>
                </div>
                <div class="col-6">
                  <div class="profile-overview">
                    <button class="btn btn-success">Más información</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-12">
          <div class="profile-card-4 text-center aniview" data-av-animation="pulse"><img src="/Img/hero.webp"
              class="img img-fluid">
            <div class="profile-content mt-5">
              <div class="profile-name">Nombre inmueble
              </div>
              <div class="profile-description">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                tempor.</div>
              <div class="row d-flex flex-wrap">
                <div class="col-6">
                  <div class="profile-overview">
                    <p><b>Precio</b></p>
                    <h4>13000</h4>
                  </div>
                </div>
                <div class="col-6">
                  <div class="profile-overview">
                    <button class="btn btn-success">Más información</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-12">
          <div class="profile-card-4 text-center aniview" data-av-animation="pulse"><img src="/Img/hero.webp"
              class="img img-fluid">
            <div class="profile-content mt-5">
              <div class="profile-name">Nombre inmueble
              </div>
              <div class="profile-description">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                tempor.</div>
              <div class="row d-flex flex-wrap">
                <div class="col-6">
                  <div class="profile-overview">
                    <p><b>Precio</b></p>
                    <h4>13000</h4>
                  </div>
                </div>
                <div class="col-6">
                  <div class="profile-overview">
                    <button class="btn btn-success">Más información</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
    </div>
@endsection