

<?php $__env->startSection('contenidoPrincipal'); ?>
<div class="container">
    <div class="col-12 mb-3 text-center mt-5">
      <h2>Por favor rellene el siguiente formulario</h2>
  </div>
    <div class="row mt-5 d-flex align-items-center justify-content-center position-relative ">
        <div class="circulo">

        </div>
        <div class="col-md-6 col-sm-12">
            <form class="row g-3 needs-validation p-3 border rounded-2 bg-white" action="" novalidate>
                <div class="col-12">
                    <label for="Nombre" class="form-label">Nombre completo:</label>
                    <input type="text" id="nombre" class="form-control" required>
                    <div class="valid-feedback">
                        Todo bien
                    </div>
                    <div class="invalid-feedback">
                        Por favor ingrese su nombre completo
                    </div>
                </div>
                                
                <div class="col-8">
                    <label for="correo" class="form-label">Correo:</label>
                    <input type="mail" id="correo" class="form-control" required>
                    <div class="valid-feedback">
                        Todo bien
                    </div>
                    <div class="invalid-feedback">
                        Por favor ingrese su correo.
                    </div>
                </div>
                <div class="col-4">
                    <label for="tel" class="form-label">Teléfono:</label>
                    <input type="text" id="tel" class="form-control" required>
                    <div class="valid-feedback">
                        Todo bien
                    </div>
                    <div class="invalid-feedback">
                        Por favor ingrese su Celular.
                    </div>
                </div>

                <div class="col-12">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inline1" value="Remodelacion" required>
                        <label class="form-check-label" for="inline1">Remodelacion</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inline2" value="nueva" required>
                        <label class="form-check-label" for="inline2">Construccion nueva</label>
                    </div>
                    <div class="valid-feedback">
                        Todo bien
                    </div>
                    <div class="invalid-feedback">
                        Por favor seleccione una opción.
                    </div>
                </div>
                <div class="col-4">
                    <label for="money" class="form-label">Presupuesto:</label>
                    <div class="input-group">
                    <span class="input-group-text">$</span>
                    <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)" required>
                    <span class="input-group-text">.00</span>
                    <div class="valid-feedback">
                        Todo bien
                    </div>
                    <div class="invalid-feedback">
                        Por favor pon un rango valido.
                    </div>
                    </div>
                </div>
                <div class="col-12">
                    <label for="pregunta1">¿Cuál es su rol?</label>
                    <select name="rol" id="rol" class="form-select" required>
                        <option value="">Seleccionar...</option>
                        <option value="1">Propietario</option>
                        <option value="2">Apoderados legales</option>
                        <option value="3">Agentes inmobiliarios</option>
                    </select>
                    <div class="valid-feedback">
                        Todo bien
                    </div>
                    <div class="invalid-feedback">
                        Por favor seleccione una opción.
                    </div>
                </div>
                
                    <button type="submit" class="btn btn-primary mb-3 mt-2 btn-color">Enviar</button>
            </form>
        </div>
        
    </div>
  </div>
  <script>
    (() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\castroinmuebles\resources\views/remodelaciones.blade.php ENDPATH**/ ?>